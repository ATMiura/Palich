$('.js-cityConfirmClose').on('click', () => {
	$('.city-confirm').hide();
});

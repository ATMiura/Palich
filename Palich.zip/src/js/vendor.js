import svg4everybody from 'svg4everybody';
import disableBodyScroll from './_vendor/disableBodyScroll';
import './_vendor/jquery.fancybox';
import './_vendor/masked-input';
import './_vendor/jquery-formstyler';

svg4everybody();

window.disableBodyScroll = disableBodyScroll;

//var objectFitImages = require('object-fit-images');
import objectFitImages from 'object-fit-images';

objectFitImages ( ) ;

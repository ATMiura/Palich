/* скрипты для шапки */
/*$(document).on('mouseenter', '.nav-item__link', function () {
	$(this).siblings('.nav-item__submenu').show();
});*/

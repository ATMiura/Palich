/* теги на страница каталога */
/*$(document).on('click', '.catalog-tags__link', function (event) {
	event.preventDefault();
	$(this).toggleClass('active');
});*/

$(document).ready(() => {
	$('.js-select').styler({
		singleSelectzIndex: 2,
		selectSmartPositioning: false
	});
});

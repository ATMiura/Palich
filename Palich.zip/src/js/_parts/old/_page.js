$(window).on('load', () => {
	$('body').addClass('is-page-loaded');
});

import './vendor';

import './_parts/_header';
import './_parts/_sliders';
import './_parts/_modal';
import './_parts/_object-fit-images';
import './_parts/_dropdown';
import './_parts/_shops-tabs';
import './_parts/_products';
import './_parts/_mobile-el-replace';
import './_parts/_catalog-list-mobile';

//import './_parts/_page';
//import './_parts/_aside';
//import './_parts/_menu';

//import './_parts/_contact';
//import './_parts/_contact-show-map';
//import './_parts/_product';
//import './_parts/_section';
//import './_parts/_animate';
//import './_parts/_modal';
//import './_parts/_helpers';


//import './_parts/_catalog';
//import './_parts/_filter';

//import './_parts/_2x';
//import './_parts/_hero';
//import './_parts/_countdown';
//import './_parts/_alert';
//import './_parts/_tab';
//import './_parts/_mask';
//import './_parts/_select';
//import './_parts/_order';
//import './_parts/_delivery';
//import './_parts/_checkout';
//import './_parts/_search';
//import './_parts/_header-tooltip';
//import './_parts/_product-day-slider';
//import './_parts/_city-confirm';
